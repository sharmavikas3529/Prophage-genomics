###############################################################################################################################################
#Prophage prediction comaprision
###############################################################################################################################################
setwd("/home/IBT/sharma/Phage-synteny/prophage-identification/github/tools-comparision-pro-per-in-host/")
library(ggplot2)
library(plyr)
library(gplots)
library(Rmisc)
library(tidyverse)
library(ggpubr)
library(rstatix)
library(reshape2)
#read table
gg <- read.delim("prokaryotes-datatable.csv", sep = "\t")

#remove after "_"
sub("_.*", "", gg$Organism.Name)->gg$genus

#replace
gsub("Mycobacteroides","Mycobacterium",as.character(gg$genus))->gg$genus


gg1<-gg[grep("bacteria", gg$Chromosome),]
droplevels(gg1)->gg1

#table with analyzed host genus 
as.data.frame(table(gg1$genus))->az
write.table(az, file = "all-genus-analysed-freq.csv", sep = "\t", quote = FALSE)


#check prophage count by virsorter (1100/2406 bacteria encode 1765 prophage)
gg1 %>% filter(Pro.count > 0)->vir
droplevels(vir)->vir


#check prophage count by vibrant (1302/2406 bacteria encode 2112 prophage)

gg1 %>% filter(V.Pro.count > 0)->vib
droplevels(vib)->vib



#check prophage prediction with both tools (vibrant and virsorter-prophage prediction is common in 959 bacteria)
gg %>% filter(Pro.count > 0 & V.Pro.count > 0)->bth
droplevels(bth)->bth

#check prophage prediction missed by one tools
gg %>% filter(Pro.count > 0 | V.Pro.count > 0)->mss
droplevels(mss)->mss

##PROPHAGE COUNT BY GENUS VIRSORTER
aggregate(mss$Pro.count, by=list(genus=mss$genus), FUN=sum)->virpro

##PROPHAGE COUNT BY GENUS VIRSORTER
aggregate(mss$V.Pro.count, by=list(genus=mss$genus), FUN=sum)->vibpro

#add column to virsorter table
virpro$tool<-"virsorter"
#add column to vibrant table
vibpro$tool<-"vibrant"


#join table
rbind(virpro, vibpro)->virvib

#number of prophage according to host genus
ggplot(data=virvib, aes(x=genus , y=x, fill = tool)) + geom_bar(stat="identity", width=.5, position = position_dodge(width = .8), show.legend = TRUE) + geom_text(aes(label = x), size=3, position = position_dodge(width = 1), vjust = -0.5) + xlab("Host genus") + ylab("Number of prophage genomes") + theme(axis.text.x = element_text(angle = 90, hjust = 1,size=10, face = "italic")) + theme(axis.text.y = element_text(hjust = 1, size=10)) + theme(axis.title.x = element_text(size=12, face="bold"),axis.title.y = element_text(size=12, face="bold")) + theme(legend.position="top")

ggsave("Distribution of prophages by host genus.pdf", width = 16, height = 10)

######################################################
###check differncce between host genus
#host without any prophage
gg1 %>% filter(V.Pro.count == 0)->vib1
droplevels(vib1)->vib1

#diffrence between host with or without prophage
as.data.frame(setdiff(vib1$genus, vib$genus))->dffr

vib1[vib1$genus %in% dffr$`setdiff(vib1$genus, vib$genus)`, ]->nopro
droplevels(nopro)->nopro

####################################################################################################################
#venn
#comparision of bacteria which encode prophage by virsorter and vibrant
library(VennDiagram)
venn.diagram(
    x = list(vir$Acc, vib$Acc), col=c("#440154ff", '#21908dff'),
    category.names = c("Virsorter" , "Vibrant" ), fill = c(alpha("#440154ff",0.3), alpha('#21908dff',0.3)),
    filename = '#Bacteria-Ven_Test.tiff',
    output=TRUE, cat.pos = 1)

#vibrant=bacterial genus do not encode prophage
gg %>% filter(V.Pro.count == 0)->vib2
droplevels(vib2)->vib2

venn.diagram(
    x = list(vib$genus, vib2$genus), col=c("#440154ff", '#21908dff'),
    category.names = c("Prophage" , "Noprophage" ), fill = c(alpha("#440154ff",0.3), alpha('#21908dff',0.3)),
    filename = '#Bacteria-with-noprophage.tiff',
    output=TRUE, cat.pos = 1)
#genus
as.data.frame(unique(gg1$genus))->nn
write.table(nn, file = "all-genus-analysis.csv", sep = "\t", quote = FALSE)
#which do not encode prophage
setdiff(vib2$genus, vib$genus)->nn
write.table(nn, file = "all-genus-no-prophage-analysis.csv", sep = "\t", quote = FALSE)

#####plasmid
#only bacteria by vibrant $virsorter 2
gg[grep("plasmid", gg$Chromosome), ]->gg1
droplevels(gg1)->gg1

#check prophage count by vibrant (1172/2406 bacteria encode 2112 prophage)

gg1 %>% filter(V.Pro.count > 0)->vib
droplevels(vib)->vib

###############################################################################################################################################
#vibrant prophage precent
#remove plasmid
gg1<-gg[grep("bacteria", gg$Chromosome),]
droplevels(gg1)->gg1

#check prophage count by vibrant (1302/2406 bacteria encode 2112 prophage)

gg1 %>% filter(V.Pro.count > 0)->vib
droplevels(vib)->vib

#remove one with 100
vib[-(1:2), , drop = FALSE]->vibbpr1
droplevels(vibbpr1)->vibbpr1

ggboxplot(vibbpr1, x = "Chromosome", y = "Vibrant..", color = "Chromosome")  + xlab("") + ylab("prophage % in host genomes") + theme(axis.text.x = element_text(size=12, face="bold")) + theme(axis.text.y = element_text(hjust = 1, size=10)) + theme(axis.title.x = element_text(size=12, face="bold"),axis.title.y = element_text(size=12, face="bold")) + theme(legend.position="top")

ggsave("prophages_percent_host_bacteria.pdf", width = 6, height = 6)

#only plasmid
gg1<-gg[-grep("bacteria", gg$Chromosome),]
droplevels(gg1)->gg1

gg1 %>% filter(V.Pro.count > 0)->vib
droplevels(vib)->vib


ggboxplot(vib, x = "Chromosome", y = "Vibrant..", color = "Chromosome")  + xlab("") + ylab("prophage % in host genomes") + theme(axis.text.x = element_text(size=12, face="bold")) + theme(axis.text.y = element_text(hjust = 1, size=10)) + theme(axis.title.x = element_text(size=12, face="bold"),axis.title.y = element_text(size=12, face="bold")) + theme(legend.position="top")

ggsave("prophages_percent_host_plasmid.pdf", width = 6, height = 6)




###############################################################################################################################################














